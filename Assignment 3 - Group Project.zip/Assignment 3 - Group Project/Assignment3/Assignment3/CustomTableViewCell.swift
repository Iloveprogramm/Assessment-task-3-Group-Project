//
//  CustomTableViewCell.swift
//  Assignment3
//
//  Created by 郑辰俊 on 25/5/2023.
//

import UIKit

class CustomTableViewCell: UITableViewCell {


    @IBOutlet weak var iconImageView: UIImageView!
    
    @IBOutlet weak var label: UILabel!
}
